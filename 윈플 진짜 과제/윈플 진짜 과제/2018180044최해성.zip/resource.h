//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Resource.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDB_MAIN                        101
#define IDB_BULLETL                     103
#define IDB_BULLETU                     104
#define IDB_BULLETR                     105
#define IDB_BULLETD                     106
#define IDB_BACKGROUND                  109
#define IDB_HELP                        110
#define IDB_LEVELSELECT                 111
#define IDB_ENEMY                       112
#define IDB_RANGE                       113
#define IDB_DEFFECT1                    115
#define IDB_DEFFECT2                    116
#define IDB_DEFFECT3                    117
#define IDB_BITMAP4                     118
#define IDB_DEFFECT4                    118

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        119
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
